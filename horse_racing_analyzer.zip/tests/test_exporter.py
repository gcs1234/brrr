from src.lovable_exporter import export_lovable_prompt

def test_export():
    main = [("HorseA", "ReasonA")]
    longshots = [("HorseB", "ReasonB")]
    cautions = [("HorseC", "ReasonC")]
    prompt = export_lovable_prompt(main, longshots, cautions)
    assert "Main Contenders" in prompt
