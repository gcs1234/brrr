from src.parser import parse_charles_town_pp

def test_parse():
    horses = parse_charles_town_pp("data/sample_pp.pdf")
    assert isinstance(horses, list)
    assert "horseName" in horses[0]
