from src.filter import filter_horses

def test_filter():
    horses = [{"horseName": "TestHorse", "lastSpeedFigure": 90}]
    rules = {"minSpeedFigure": 85}
    main, longshots, cautions = filter_horses(horses, rules)
    assert main
