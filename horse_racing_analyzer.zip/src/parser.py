import pdfplumber
import re

def parse_charles_town_pp(pdf_path):
    return [{"horseName": "Example", "lastSpeedFigure": 90, "jockeyWinPct": 15, "trainerWinPct": 12, "positions": [4, 2, 1]}]
