import json

def load_rules(rules_path):
    with open(rules_path, 'r') as f:
        return json.load(f)
