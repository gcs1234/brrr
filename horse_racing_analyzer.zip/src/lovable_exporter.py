def export_lovable_prompt(main_contenders, longshots, cautions):
    prompt = "🏇 **Main Contenders:**\n"
    for name, reason in main_contenders:
        prompt += f"- {name}: {reason}\n"
    prompt += "\n🔍 **Longshots to Watch:**\n"
    for name, reason in longshots:
        prompt += f"- {name}: {reason}\n"
    prompt += "\n⚠️ **Cautions:**\n"
    for name, reason in cautions:
        prompt += f"- {name}: {reason}\n"
    return prompt
