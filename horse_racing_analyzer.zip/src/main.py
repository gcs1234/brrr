from parser import parse_charles_town_pp
from rules import load_rules
from filter import filter_horses
from lovable_exporter import export_lovable_prompt

if __name__ == "__main__":
    horses = parse_charles_town_pp("data/sample_pp.pdf")
    rules = load_rules("data/user_rules.json")
    main, longshots, cautions = filter_horses(horses, rules)
    prompt = export_lovable_prompt(main, longshots, cautions)
    print(prompt)
