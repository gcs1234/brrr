def filter_horses(horses, rules):
    main_contenders, longshots, cautions = [], [], []
    for horse in horses:
        if horse['lastSpeedFigure'] >= rules['minSpeedFigure']:
            main_contenders.append((horse['horseName'], "Matches rules"))
        else:
            cautions.append((horse['horseName'], "Below speed threshold"))
    return main_contenders, longshots, cautions
