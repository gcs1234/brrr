# Horse Racing Analyzer

This project parses Charles Town PPs, applies filtering rules, and exports a Lovable AI-compatible prompt.
